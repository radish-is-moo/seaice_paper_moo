# Upstream data and preprocessing boundary

PIOMAS: https://psc.apl.uw.edu/research/projects/arctic-sea-ice-volume-anomaly/data/ and https://pscfiles.apl.uw.edu/zhang/PIOMAS/ . Obtain daily SIC and SIT for 1979–2025 from the provider. Cite Zhang and Rothrock (2003) and the manuscript PIOMAS references. Do not replace daily fields with monthly fields. Provider file revision and download dates for the original experiment were not established by this release audit.

ERA5: https://cds.climate.copernicus.eu/datasets/reanalysis-era5-single-levels?tab=overview ; DOI 10.24381/cds.adbb2d47. Required variables: 2-m temperature, 2-m dewpoint temperature, 10-m u and v wind, mean sea-level pressure, sea-surface temperature; 1979–2025. Use the provider download form/API with the applicable source terms. The original hourly selection/daily aggregation and upstream spatial remapping must be verified before claiming bitwise reconstruction from fresh downloads. This release does not invent a retrieval request or a product revision.

Evaluation: 2023–2025 ver2, 282 paired initializations, all 30 target dates in July–October, static ocean mask including open water. Training 1979–2019; validation 2020–2022. No 2020–2025 evaluation experiment is bundled.

The evaluation_context archive supplies the exact 282 initialization-day cached fields and the 1979–2019 reference climatology used by diagnostics. It does not supply the full 1979–2025 daily training cache or all 15-day input histories. Evaluation of frozen forecasts and re-training are distinct reproducibility levels. Derived source fields remain subject to upstream terms.
