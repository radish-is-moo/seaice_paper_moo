# Release scope, 2026-09-23
Code, notebooks, environment, small figure inputs, masks, three model checkpoints and normalization statistics are included here. Checkpoint/statistics hashes match the metadata in the frozen forecast archives.

Separate files: predictions_MODEL_YEAR.zip (9), references_YEAR.zip (3), evaluation_context.zip (1). These contain 846 predictions, 282 references, 282 initialization-day input caches, and the 1979–2019 reference climatology. Every forecast/reference hash matched the published frozen manifest.

Extract these ZIPs into data/external/. The resulting directories must be data/external/archives/ and data/external/daily_cache/. paths.example.json points to the bundled weights. ERA5 grid sample remains an external input; see docs/data.md. Full 15-day histories and the complete training cache are not bundled.

Source datasets: see raw_data_sources.md. Full reconstruction from fresh downloads still requires verification of original dataset revisions, temporal aggregation and spatial remapping. Do not claim all raw data or fully automated retraining are provided.

Publication status: files prepared locally; GitHub update and external data deposit are not performed. Add real repository URLs/version identifiers after deposit. Original project code is MIT-licensed; see LICENSE_SCOPE.md. Provider-derived data retain their source terms.
